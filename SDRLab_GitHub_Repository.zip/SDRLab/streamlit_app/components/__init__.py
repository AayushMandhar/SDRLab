"""
Streamlit dashboard UI components.
"""
